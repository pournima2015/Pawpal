# PawPal V2 — Animation & UI Reference Prompts

The approved dashboard direction was inspired by interaction patterns from:

- https://ui.aceternity.com/
- https://animmasterlib.dev/
- https://www.designprompts.dev/

These references were used as inspiration for interaction patterns, not as a requirement to convert PawPal to React/Tailwind.

## Adapted prompt 1 — PawPal dashboard

Create a calm, premium pet-care dashboard using PawPal's existing nature-inspired visual system. Use a warm paper background, pine green primary color, soft sage surfaces, amber/clay accents, rounded cards and subtle shadows. Keep the information hierarchy simple. Add a welcoming hero, pet overview, upcoming reminders, quick-action cards and a clearly separated Animal SOS action. Use small motion only where it improves orientation and feedback.

## Adapted prompt 2 — Scroll reveal

Add subtle scroll-triggered reveal animations to sections. Elements should fade and move upward by a small distance as they enter the viewport. Keep duration short and respect prefers-reduced-motion. Never animate essential content in a way that delays access.

## Adapted prompt 3 — Spotlight cards

Add a mouse-following radial spotlight to important cards. The effect should be very soft, remain within the card, and disappear when the pointer leaves. The content must remain readable and the interaction must not change layout.

## Adapted prompt 4 — Magnetic buttons

Use a very small pointer-following movement on selected primary buttons. The movement should be subtle, spring-like and optional. Do not apply it to emergency buttons where predictability is more important.

## Adapted prompt 5 — Hover interactions

Make feature cards feel interactive through a small upward translation, shadow change, border emphasis and icon movement. Keep hover feedback under 350ms and preserve accessibility for keyboard users.

## Adapted prompt 6 — Animal SOS

Design the Animal SOS section as a high-priority action without making the whole application feel alarming. Use a restrained clay/red accent, clear language, direct contact actions and verified-service labels. The emergency path should be shorter than the normal FAQ/query path.

## Reference component concepts

Aceternity UI component concepts reviewed:
- Card Hover Effect
- Card Spotlight
- Glowing Effect
- Moving Border
- Magnetic Button
- Background Gradient
- Hover Border Gradient
- Text Reveal / scroll reveal patterns

Animmaster concepts reviewed:
- Scroll Animation
- Smooth Hover Effect
- Hero Animation
- Mouse Effect
- Navigation Menu
- Page Transition

The implementation in this project is intentionally written in plain HTML/CSS/JavaScript so it fits the existing PawPal project.
