const checks=[...document.querySelectorAll('.compatibility input')];checks.forEach(c=>c.addEventListener('change',()=>{const done=checks.filter(x=>x.checked).length;if(done===checks.length)window.showToast?.('You have reviewed every checklist item.')}));


const findAdoptionBtn=document.getElementById('findAdoptionBtn');
const adoptionResults=document.getElementById('adoptionResults');
const adoptionStatus=document.getElementById('adoptionStatus');
findAdoptionBtn?.addEventListener('click',async()=>{
  findAdoptionBtn.disabled=true;
  adoptionStatus.textContent='Requesting your location…';
  adoptionResults.innerHTML='<div class="card"><p class="muted">Finding nearby adoption centers…</p></div>';
  try{
    const pos=await window.PawPalNearby.location();
    const items=await window.PawPalNearby.find('shelters',pos);
    adoptionStatus.textContent=`Showing ${items.length} adoption center${items.length===1?'':'s'} within 5 km of your current location.`;
    adoptionResults.innerHTML=items.length?items.slice(0,12).map(x=>window.PawPalNearby.renderCard(x,'Adoption center')).join(''):'<div class="card"><h3>No nearby adoption centers found</h3><p class="muted">Try again later or search a wider area in Maps.</p></div>';
    window.lucide?.createIcons();
  }catch(err){
    adoptionStatus.textContent=err.message;
    adoptionResults.innerHTML='<div class="card"><h3>Could not load nearby adoption centers</h3><p class="muted">'+err.message+'</p></div>';
  }finally{findAdoptionBtn.disabled=false;}
});
