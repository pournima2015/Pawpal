import {supabase,SUPABASE_CONFIGURED} from '../supabase/config.js';
const f=document.getElementById('foodForm');
if(f)f.addEventListener('submit',async e=>{e.preventDefault();const m=document.getElementById('feedingMessage');if(!SUPABASE_CONFIGURED){m.textContent='Configure Supabase first.';m.className='notice error';return}try{const {data:{user}}=await supabase.auth.getUser();if(!user)return location.href='login.html';const pid=document.getElementById('petId').value.trim();const {data:pet,error:pe}=await supabase.from('pets').select('id').eq('id',pid).eq('user_id',user.id).single();if(pe||!pet)throw new Error('Pet ID was not found in your account.');const {error}=await supabase.from('feeding_routines').insert({user_id:user.id,pet_id:pid,food_type:document.getElementById('foodType').value.trim(),feeding_time:document.getElementById('feedingTime').value,portion:document.getElementById('foodAmount').value.trim(),notes:document.getElementById('foodNotes').value.trim()});if(error)throw error;m.textContent='Feeding routine saved.';m.className='notice';f.reset()}catch(err){m.textContent=err.message;m.className='notice error'}});


const findPetShopsBtn=document.getElementById('findPetShopsBtn');
const petShopResults=document.getElementById('petShopResults');
const petShopStatus=document.getElementById('petShopStatus');
findPetShopsBtn?.addEventListener('click',async()=>{
  findPetShopsBtn.disabled=true;
  petShopStatus.textContent='Requesting your location…';
  petShopResults.innerHTML='<div class="card"><p class="muted">Finding nearby pet shops…</p></div>';
  try{
    const pos=await window.PawPalNearby.location();
    const items=await window.PawPalNearby.find('petshops',pos);
    petShopStatus.textContent=`Showing ${items.length} pet shop${items.length===1?'':'s'} within 5 km of your current location.`;
    petShopResults.innerHTML=items.length?items.slice(0,12).map(x=>window.PawPalNearby.renderCard(x,'Pet food shop')).join(''):'<div class="card"><h3>No nearby pet shops found</h3><p class="muted">Try again later or search a wider area in Maps.</p></div>';
    window.lucide?.createIcons();
  }catch(err){
    petShopStatus.textContent=err.message;
    petShopResults.innerHTML='<div class="card"><h3>Could not load nearby pet shops</h3><p class="muted">'+err.message+'</p></div>';
  }finally{findPetShopsBtn.disabled=false;}
});
