import {supabase,SUPABASE_CONFIGURED} from '../supabase/config.js';
const f=document.getElementById('groomingForm');
if(f)f.addEventListener('submit',async e=>{e.preventDefault();const m=document.getElementById('groomingMessage');if(!SUPABASE_CONFIGURED){m.textContent='Configure Supabase first.';m.className='notice error';return}try{const {data:{user}}=await supabase.auth.getUser();if(!user)return location.href='login.html';const pid=document.getElementById('petId').value.trim();const {data:pet,error:pe}=await supabase.from('pets').select('id').eq('id',pid).eq('user_id',user.id).single();if(pe||!pet)throw new Error('Pet ID was not found in your account.');const date=document.getElementById('date').value;const {error}=await supabase.from('reminders').insert({user_id:user.id,pet_id:pid,title:document.getElementById('task').value,reminder_type:'Grooming',reminder_date:date,notes:document.getElementById('notes').value.trim()});if(error)throw error;document.getElementById('nextGroomingDate').textContent=new Date(`${date}T00:00:00`).toLocaleDateString();m.textContent='Grooming reminder saved.';m.className='notice';f.reset()}catch(err){m.textContent=err.message;m.className='notice error'}});

const findGroomingBtn=document.getElementById('findGroomingBtn');
const groomingResults=document.getElementById('groomingResults');
const groomingLocationStatus=document.getElementById('groomingLocationStatus');
findGroomingBtn?.addEventListener('click',async()=>{
  findGroomingBtn.disabled=true;
  findGroomingBtn.setAttribute('aria-busy','true');
  groomingLocationStatus.textContent='Requesting your location…';
  groomingResults.innerHTML='<div class="card"><p class="muted">Finding nearby pet grooming parlours…</p></div>';
  try{
    const pos=await window.PawPalNearby.location();
    const items=await window.PawPalNearby.find('grooming',pos);
    groomingLocationStatus.textContent=`Showing ${items.length} grooming parlour${items.length===1?'':'s'} within 5 km of your current location.`;
    groomingResults.innerHTML=items.length
      ? items.slice(0,12).map(x=>window.PawPalNearby.renderCard(x,'Grooming parlour')).join('')
      : '<div class="card"><h3>No nearby grooming parlours found</h3><p class="muted">OpenStreetMap may not have grooming services mapped in your area yet. Try again later or search a wider area in Maps.</p><div class="actions"><a class="btn btn-outline" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=pet+grooming+near+me">Search Maps</a></div></div>';
    window.lucide?.createIcons();
  }catch(err){
    groomingLocationStatus.textContent=err.message;
    groomingResults.innerHTML='<div class="card"><h3>Could not load nearby grooming parlours</h3><p class="muted">'+err.message+'</p><div class="actions"><a class="btn btn-outline" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=pet+grooming+near+me">Search Maps</a></div></div>';
  }finally{
    findGroomingBtn.disabled=false;
    findGroomingBtn.removeAttribute('aria-busy');
  }
});
