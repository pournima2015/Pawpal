const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

function initSharedUI(){
  document.body.classList.add('page-ready');
  const menu=document.getElementById('mobileMenuBtn');
  const drawer=document.getElementById('mobileDrawer');
  if(menu&&drawer) menu.addEventListener('click',()=>drawer.classList.toggle('open'));
  document.querySelectorAll('.spotlight').forEach(card=>card.addEventListener('pointermove',e=>{const r=card.getBoundingClientRect();card.style.setProperty('--mx',`${e.clientX-r.left}px`);card.style.setProperty('--my',`${e.clientY-r.top}px`)}));
  if(!reduceMotion&&'IntersectionObserver' in window){const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');io.unobserve(e.target)}}),{threshold:.12});document.querySelectorAll('.reveal').forEach(el=>io.observe(el));}
  document.querySelectorAll('[data-magnetic]').forEach(btn=>{btn.addEventListener('pointermove',e=>{if(reduceMotion)return;const r=btn.getBoundingClientRect();btn.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.05}px,${(e.clientY-r.top-r.height/2)*.05}px)`});btn.addEventListener('pointerleave',()=>btn.style.transform='')});
}
window.showToast=(message,kind='ok')=>{let t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';t.className='toast';document.body.appendChild(t)}t.textContent=message;t.style.background=kind==='error'?'#9b4031':'#245548';t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)};
initSharedUI();


/* Nearby services: browser location + OpenStreetMap/Overpass. No fake coordinates or API key. */
const nearbyCache = new Map();
function pawpalDistanceKm(lat1, lon1, lat2, lon2){
  const R=6371, rad=Math.PI/180, dLat=(lat2-lat1)*rad, dLon=(lon2-lon1)*rad;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*rad)*Math.cos(lat2*rad)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
function pawpalEscape(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function pawpalMapsUrl(lat,lon){return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${lat},${lon}`)}`;}
function pawpalLocation(options={}){
  const timeout=options.timeout||12000;
  if(!navigator.geolocation) return Promise.reject(new Error('Location is not supported by this browser.'));
  return new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(
    p=>resolve({lat:p.coords.latitude,lon:p.coords.longitude,accuracy:p.coords.accuracy}),
    e=>reject(new Error(e.code===1?'Location permission was denied. Please allow location access and try again.':'Unable to get your current location. Please try again.')),
    {enableHighAccuracy:true,timeout,maximumAge:300000}
  ));
}
async function pawpalOverpass(query){
  const endpoints=['https://overpass-api.de/api/interpreter','https://overpass.kumi.systems/api/interpreter'];
  let last;
  for(const endpoint of endpoints){
    try{
      const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body:new URLSearchParams({data:query})});
      if(!r.ok) throw new Error(`Nearby service returned ${r.status}`);
      return await r.json();
    }catch(e){last=e;}
  }
  throw last||new Error('Nearby service is unavailable.');
}
async function pawpalNearby(kind,{lat,lon,radius=5000}={}){
  const key=`${kind}:${lat.toFixed(3)}:${lon.toFixed(3)}:${radius}`;
  if(nearbyCache.has(key)) return nearbyCache.get(key);
  const filters={
    vets:'nwr["amenity"="veterinary"]',
    petshops:'nwr["shop"="pet"]',
    shelters:'nwr["amenity"="animal_shelter"]',
    grooming:'nwr["pet_grooming"="yes"]',
    rescue:'nwr["amenity"="animal_shelter"]'
  };
  const selector=filters[kind];
  if(!selector) throw new Error('Unknown nearby service.');
  const query=kind==='grooming'
    ? `[out:json][timeout:25];(nwr["pet_grooming"="yes"](around:${radius},${lat},${lon});nwr["shop"="pet"]["pet_grooming"="yes"](around:${radius},${lat},${lon});nwr["name"~"groom|pet salon|pet spa",i](around:${radius},${lat},${lon}););out center tags;`
    : `[out:json][timeout:20];(${selector}(around:${radius},${lat},${lon}););out center tags;`;
  const data=await pawpalOverpass(query);
  const items=(data.elements||[]).map(el=>{
    const p=el.type==='node'?{lat:el.lat,lon:el.lon}:el.center;
    if(!p) return null;
    const t=el.tags||{};
    const name=t.name||t['name:en']||'Unnamed service';
    const address=[t['addr:housenumber'],t['addr:street'],t['addr:suburb'],t['addr:city']].filter(Boolean).join(', ');
    return {id:`${el.type}-${el.id}`,name,lat:p.lat,lon:p.lon,distance:pawpalDistanceKm(lat,lon,p.lat,p.lon),address,phone:t.phone||t['contact:phone']||'',website:t.website||t['contact:website']||'',opening:t.opening_hours||''};
  }).filter(Boolean).sort((a,b)=>a.distance-b.distance);
  nearbyCache.set(key,items);
  return items;
}
function pawpalNearbyCard(item,label='Nearby service'){
  const phone=item.phone?`<a class="btn btn-secondary" href="tel:${pawpalEscape(item.phone)}"><i data-lucide="phone"></i>Call</a>`:'';
  const website=item.website?`<a class="btn btn-outline" target="_blank" rel="noopener" href="${pawpalEscape(item.website)}"><i data-lucide="external-link"></i>Website</a>`:'';
  return `<article class="card nearby-card"><div class="row between"><span class="badge">${pawpalEscape(label)}</span><span class="distance">${item.distance<1?(item.distance*1000).toFixed(0)+' m':item.distance.toFixed(1)+' km'}</span></div><h3>${pawpalEscape(item.name)}</h3><p class="muted">${pawpalEscape(item.address||'Address not listed in OpenStreetMap')}</p>${item.opening?`<p class="muted"><strong>Hours:</strong> ${pawpalEscape(item.opening)}</p>`:''}<div class="actions"><a class="btn btn-primary" target="_blank" rel="noopener" href="${pawpalMapsUrl(item.lat,item.lon)}"><i data-lucide="navigation"></i>Directions</a>${phone}${website}</div></article>`;
}
window.PawPalNearby={location:pawpalLocation,find:pawpalNearby,renderCard:pawpalNearbyCard};
