// Pet Care is currently educational content. Shared animations are handled by main.js.
