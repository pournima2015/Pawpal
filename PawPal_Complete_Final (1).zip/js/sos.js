import {supabase,SUPABASE_CONFIGURED} from '../supabase/config.js';
const status=document.getElementById('locationStatus');
const contactsBox=document.getElementById('sosContacts');
function escapeHtml(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function distanceKm(lat1,lon1,lat2,lon2){const R=6371,r=Math.PI/180,dLat=(lat2-lat1)*r,dLon=(lon2-lon1)*r,a=Math.sin(dLat/2)**2+Math.cos(lat1*r)*Math.cos(lat2*r)*Math.sin(dLon/2)**2;return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}
async function loadVerifiedContacts(pos){
  if(!SUPABASE_CONFIGURED) return [];
  const {data,error}=await supabase.from('rescue_contacts').select('id,name,service_type,phone,address,city,latitude,longitude,website').eq('verified',true).eq('active',true);
  if(error) throw error;
  return (data||[]).filter(x=>Number.isFinite(x.latitude)&&Number.isFinite(x.longitude)).map(x=>({...x,distance:distanceKm(pos.lat,pos.lon,x.latitude,x.longitude)})).sort((a,b)=>a.distance-b.distance);
}
function contactCard(c){
  const call=c.phone?`<a class="btn btn-danger" href="tel:${encodeURIComponent(c.phone)}"><i data-lucide="phone-call"></i>Call now</a>`:'';
  const directions=`<a class="btn btn-outline" target="_blank" rel="noopener" href="https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${c.latitude},${c.longitude}`)}"><i data-lucide="navigation"></i>Directions</a>`;
  const website=c.website?`<a class="btn btn-secondary" target="_blank" rel="noopener" href="${escapeHtml(c.website)}"><i data-lucide="external-link"></i>Website</a>`:'';
  return `<article class="contact-row"><div><strong>${escapeHtml(c.name)}</strong><div class="muted">${escapeHtml(c.service_type)} · ${c.distance<1?(c.distance*1000).toFixed(0)+' m':c.distance.toFixed(1)+' km'}</div><div class="muted">${escapeHtml(c.address||c.city||'Address not listed')}</div><div class="actions">${call}${directions}${website}</div></div><span class="verified">Verified</span></article>`;
}
async function requestLocation(){
  if(!window.PawPalNearby){status.textContent='Nearby location service is not loaded.';return;}
  status.textContent='Finding verified emergency contacts near you…';
  contactsBox.innerHTML='<div class="contact-row"><div><strong>Searching nearby…</strong><div class="muted">Checking verified rescue contacts in PawPal.</div></div></div>';
  try{
    const pos=await window.PawPalNearby.location();
    const contacts=await loadVerifiedContacts(pos);
    status.textContent=`Location ready · ${pos.accuracy<100?`accuracy ±${Math.round(pos.accuracy)} m`: 'location acquired'}`;
    if(!contacts.length){
      contactsBox.innerHTML='<div class="contact-row"><div><strong>No verified emergency contacts are configured nearby.</strong><div class="muted">Add verified rescue, bird rescue or animal ambulance contacts to Supabase with latitude and longitude. Nothing is invented or guessed.</div></div><span class="verified">Verified only</span></div>';
    }else{
      contactsBox.innerHTML=contacts.slice(0,12).map(contactCard).join('');
      window.lucide?.createIcons();
    }
  }catch(err){
    status.textContent=err.message;
    contactsBox.innerHTML=`<div class="contact-row"><div><strong>Could not load emergency contacts</strong><div class="muted">${escapeHtml(err.message)}</div></div></div>`;
  }
}
document.getElementById('sosLocateBtn')?.addEventListener('click',requestLocation);
