import {supabase,SUPABASE_CONFIGURED} from '../supabase/config.js';
const form=document.getElementById('vetUploadForm');if(form)form.addEventListener('submit',async e=>{e.preventDefault();const m=document.getElementById('vetMessage');if(!SUPABASE_CONFIGURED){m.textContent='Configure Supabase first.';m.className='notice error';return}try{const {data:{user}}=await supabase.auth.getUser();if(!user)return location.href='login.html';const pid=document.getElementById('petId').value.trim(),file=document.getElementById('vetDocument').files[0];if(!file)throw new Error('Choose a document first.');const {data:pet,error:pe}=await supabase.from('pets').select('id').eq('id',pid).eq('user_id',user.id).single();if(pe||!pet)throw new Error('Pet ID was not found in your account.');const path=`${user.id}/${pid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`;const up=await supabase.storage.from('vet-documents').upload(path,file);if(up.error)throw up.error;const {error}=await supabase.from('health_records').insert({user_id:user.id,pet_id:pid,title:document.getElementById('documentType').value,record_type:'Veterinary Document',vet_document_path:path});if(error)throw error;m.textContent='Veterinary document uploaded successfully.';m.className='notice';form.reset()}catch(err){m.textContent=err.message;m.className='notice error'}});
const nearby=document.getElementById('findNearbyBtn');
const results=document.getElementById('vetResults');
const status=document.getElementById('vetLocationStatus');
async function loadNearbyVets(){
  if(!window.PawPalNearby) return;
  nearby.disabled=true; nearby.setAttribute('aria-busy','true');
  if(status) status.textContent='Requesting your location…';
  if(results) results.innerHTML='<div class="card"><p class="muted">Finding nearby veterinary services…</p></div>';
  try{
    const pos=await window.PawPalNearby.location();
    const items=await window.PawPalNearby.find('vets',pos);
    if(status) status.textContent=`Showing ${items.length} veterinary service${items.length===1?'':'s'} within 5 km of your current location.`;
    if(!items.length){
      results.innerHTML='<div class="card"><h3>No nearby veterinary services found</h3><p class="muted">Try again with location enabled or open Google Maps to search a wider area.</p><div class="actions"><a class="btn btn-primary" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=veterinary+clinic+near+me">Open Maps</a></div></div>';
    }else{
      results.innerHTML=items.slice(0,12).map(x=>window.PawPalNearby.renderCard(x,'Veterinary service')).join('');
      window.lucide?.createIcons();
    }
    const q=document.getElementById('vetSearch'); if(q) q.value='Nearby veterinary services';
  }catch(err){
    if(status) status.textContent=err.message;
    if(results) results.innerHTML='<div class="card"><h3>Could not load nearby services</h3><p class="muted">'+err.message+'</p><div class="actions"><a class="btn btn-outline" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=veterinary+clinic+near+me">Search in Maps</a></div></div>';
  }finally{nearby.disabled=false;nearby.removeAttribute('aria-busy');}
}
nearby?.addEventListener('click',loadNearbyVets);
