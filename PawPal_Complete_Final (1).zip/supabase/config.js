import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm';

// Replace these two placeholders with the values from Supabase Project Settings > API.
export const SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
export const SUPABASE_PUBLISHABLE_KEY = 'PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE';
export const SUPABASE_CONFIGURED = SUPABASE_URL.startsWith('https://') && !SUPABASE_URL.includes('PASTE_') && !SUPABASE_PUBLISHABLE_KEY.includes('PASTE_');

export const supabase = createClient(
  SUPABASE_CONFIGURED ? SUPABASE_URL : 'https://placeholder.supabase.co',
  SUPABASE_CONFIGURED ? SUPABASE_PUBLISHABLE_KEY : 'placeholder-public-key',
  { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } }
);
