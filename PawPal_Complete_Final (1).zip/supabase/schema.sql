-- PawPal Supabase starter schema
-- Run in Supabase SQL Editor. Review policies for your deployment before production use.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  phone text,
  city text,
  address text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.pets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  species text,
  breed text,
  age numeric,
  gender text,
  weight numeric,
  photo_path text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.health_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  pet_id uuid not null references public.pets(id) on delete cascade,
  title text not null,
  record_type text,
  visit_date date,
  veterinarian text,
  clinic text,
  symptoms text,
  diagnosis text,
  treatment text,
  medicines text,
  follow_up_date date,
  vet_notes text,
  prescription_path text,
  vet_document_path text,
  medical_report_path text,
  medicine_photo_path text,
  created_at timestamptz default now()
);

create table if not exists public.reminders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  pet_id uuid not null references public.pets(id) on delete cascade,
  title text not null,
  reminder_type text,
  reminder_date date,
  notes text,
  completed boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.feeding_routines (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  pet_id uuid not null references public.pets(id) on delete cascade,
  food_type text,
  feeding_time time,
  portion text,
  notes text,
  created_at timestamptz default now()
);

create table if not exists public.rescue_contacts (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  service_type text not null,
  phone text not null,
  address text,
  city text,
  latitude double precision,
  longitude double precision,
  website text,
  verified boolean default false,
  active boolean default true,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.pets enable row level security;
alter table public.health_records enable row level security;
alter table public.reminders enable row level security;
alter table public.feeding_routines enable row level security;
alter table public.rescue_contacts enable row level security;

create policy "profiles own select" on public.profiles for select using (auth.uid() = id);
create policy "profiles own insert" on public.profiles for insert with check (auth.uid() = id);
create policy "profiles own update" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);

create policy "pets own select" on public.pets for select using (auth.uid() = user_id);
create policy "pets own insert" on public.pets for insert with check (auth.uid() = user_id);
create policy "pets own update" on public.pets for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "pets own delete" on public.pets for delete using (auth.uid() = user_id);

create policy "health own select" on public.health_records for select using (auth.uid() = user_id);
create policy "health own insert" on public.health_records for insert with check (auth.uid() = user_id);
create policy "health own update" on public.health_records for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "health own delete" on public.health_records for delete using (auth.uid() = user_id);

create policy "reminders own select" on public.reminders for select using (auth.uid() = user_id);
create policy "reminders own insert" on public.reminders for insert with check (auth.uid() = user_id);
create policy "reminders own update" on public.reminders for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "reminders own delete" on public.reminders for delete using (auth.uid() = user_id);

create policy "feeding own select" on public.feeding_routines for select using (auth.uid() = user_id);
create policy "feeding own insert" on public.feeding_routines for insert with check (auth.uid() = user_id);
create policy "feeding own update" on public.feeding_routines for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "feeding own delete" on public.feeding_routines for delete using (auth.uid() = user_id);

create policy "verified rescue read" on public.rescue_contacts for select using (verified = true and active = true);

insert into storage.buckets (id,name,public) values
  ('pet-photos','pet-photos',false),
  ('prescriptions','prescriptions',false),
  ('vet-documents','vet-documents',false),
  ('medical-reports','medical-reports',false),
  ('medicine-photos','medicine-photos',false)
on conflict (id) do nothing;

create policy "storage own read" on storage.objects for select to authenticated using (bucket_id in ('pet-photos','prescriptions','vet-documents','medical-reports','medicine-photos') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "storage own upload" on storage.objects for insert to authenticated with check (bucket_id in ('pet-photos','prescriptions','vet-documents','medical-reports','medicine-photos') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "storage own update" on storage.objects for update to authenticated using (bucket_id in ('pet-photos','prescriptions','vet-documents','medical-reports','medicine-photos') and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id in ('pet-photos','prescriptions','vet-documents','medical-reports','medicine-photos') and (storage.foldername(name))[1] = auth.uid()::text);
create policy "storage own delete" on storage.objects for delete to authenticated using (bucket_id in ('pet-photos','prescriptions','vet-documents','medical-reports','medicine-photos') and (storage.foldername(name))[1] = auth.uid()::text);
